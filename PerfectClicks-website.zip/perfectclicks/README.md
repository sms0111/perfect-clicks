# PerfectClicks Website Prototype

## Included
- Modern responsive homepage
- Featured photos and information posts
- Category filters and search
- Upload modal with photo preview
- Photo post / information post tabs
- Generated demo shareable post links
- Login / Sign Up UI
- Forgot password entry point
- Responsive mobile layout

## Run locally
Open `index.html` in a browser.

## Important
This is a front-end prototype. Real user accounts, persistent uploads, database storage, secure authentication, and production share links require a backend and hosting/database configuration.
