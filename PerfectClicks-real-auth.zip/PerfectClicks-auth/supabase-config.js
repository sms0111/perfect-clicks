// Replace these two values with your Supabase project's browser-safe credentials.
// Supabase Dashboard -> Project Settings -> API.
// NEVER put a secret/service_role key in this file.
window.SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.SUPABASE_PUBLISHABLE_KEY = "YOUR_SUPABASE_PUBLISHABLE_KEY";
