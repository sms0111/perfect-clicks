# PerfectClicks — Real Authentication

This package wires the PerfectClicks auth UI to Supabase Auth.

## 1. Create a Supabase project
Create a project at https://supabase.com/.

## 2. Configure the browser-safe keys
Open `supabase-config.js` and replace:
- SUPABASE_URL
- SUPABASE_PUBLISHABLE_KEY

Use the project's publishable/browser key. NEVER put a secret/service_role key in browser code.

## 3. Create the profile table
Open Supabase Dashboard -> SQL Editor and run `schema.sql`.
The SQL enables Row Level Security and creates a profile row after signup.

## 4. Configure Auth URLs
In Supabase Authentication URL settings, add your deployed site URL as an allowed redirect URL.
For local testing, also add your local origin (for example http://localhost:5500).

## 5. Email confirmation
Supabase can require email confirmation. Signup will show a message telling the user to check their email.

## 6. Password reset
The reset flow sends an email and returns the user to this page; the app listens for PASSWORD_RECOVERY and lets the user set a new password.

## 7. Google login
The Google button is wired to Supabase OAuth, but Google provider credentials must be enabled/configured in your Supabase Auth provider settings.

## Important
The `publishable` key is intended for client-side use. Never expose a Supabase secret/service_role key in this site.
