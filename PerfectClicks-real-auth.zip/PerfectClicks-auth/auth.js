const { createClient } = supabase;
const client = createClient(window.SUPABASE_URL, window.SUPABASE_PUBLISHABLE_KEY);

const $ = (id) => document.getElementById(id);
let authMode = "login";

function msg(text, ok=false) {
  const el = $("authMessage");
  el.textContent = text;
  el.className = ok ? "message success" : "message error";
  el.style.display = "block";
}
function clearMsg(){ $("authMessage").style.display="none"; }

function openAuth(mode="login") {
  authMode = mode;
  clearMsg();
  $("authModal").classList.add("show");
  $("authTitle").textContent = mode === "signup" ? "Create Your Account" : "Welcome Back";
  $("authSubtitle").textContent = mode === "signup"
    ? "Create your PerfectClicks account and start sharing."
    : "Login to your PerfectClicks account.";
  $("nameWrap").style.display = mode === "signup" ? "block" : "none";
  $("usernameWrap").style.display = mode === "signup" ? "block" : "none";
  $("authAction").textContent = mode === "signup" ? "Create Account" : "Login";
  $("switchAuth").textContent = mode === "signup"
    ? "Already have an account? Login"
    : "Don't have an account? Sign Up";
}
function closeAuth(){ $("authModal").classList.remove("show"); }

async function submitAuth() {
  clearMsg();
  const email = $("authEmail").value.trim();
  const password = $("authPassword").value;
  if (!email || !password) return msg("Please enter your email and password.");

  if (authMode === "signup") {
    const full_name = $("fullName").value.trim();
    const username = $("username").value.trim().toLowerCase();
    if (!full_name) return msg("Please enter your full name.");
    const { data, error } = await client.auth.signUp({
      email, password,
      options: {
        emailRedirectTo: window.location.origin + window.location.pathname,
        data: { full_name, username }
      }
    });
    if (error) return msg(error.message);
    if (data.session) {
      closeAuth();
      openProfile();
      msgGlobal("Account created successfully.", true);
    } else {
      msg("Account created. Check your email to confirm your account, then log in.", true);
    }
  } else {
    const { data, error } = await client.auth.signInWithPassword({ email, password });
    if (error) return msg(error.message);
    closeAuth();
    msgGlobal("Logged in successfully.", true);
    await refreshUser();
  }
}

async function forgotPassword() {
  clearMsg();
  const email = $("authEmail").value.trim();
  if (!email) return msg("Enter your email first.");
  const { error } = await client.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin + window.location.pathname + "#reset"
  });
  if (error) return msg(error.message);
  msg("Password reset link sent. Check your email.", true);
}

async function updatePassword() {
  const password = $("newPassword").value;
  if (!password || password.length < 6) return msgReset("Password must be at least 6 characters.");
  const { error } = await client.auth.updateUser({ password });
  if (error) return msgReset(error.message);
  $("resetModal").classList.remove("show");
  msgGlobal("Password updated successfully. You are logged in.", true);
}

function msgReset(t){
  $("resetMessage").textContent=t;
  $("resetMessage").style.display="block";
}

async function saveProfile() {
  const { data: { user } } = await client.auth.getUser();
  if (!user) return;
  const payload = {
    id: user.id,
    full_name: $("profileName").value.trim(),
    username: $("profileUsername").value.trim().toLowerCase(),
    bio: $("profileBio").value.trim(),
    location: $("profileLocation").value.trim(),
    updated_at: new Date().toISOString()
  };
  const { error } = await client.from("profiles").upsert(payload);
  if (error) return msgProfile(error.message);
  $("profileModal").classList.remove("show");
  msgGlobal("Profile saved.", true);
  await refreshUser();
}

function msgProfile(t){
  $("profileMessage").textContent=t;
  $("profileMessage").style.display="block";
}

async function openProfile() {
  const { data: { user } } = await client.auth.getUser();
  if (!user) return openAuth("login");
  $("profileModal").classList.add("show");
  $("profileMessage").style.display="none";
  const { data } = await client.from("profiles").select("*").eq("id", user.id).maybeSingle();
  $("profileName").value = data?.full_name || user.user_metadata?.full_name || "";
  $("profileUsername").value = data?.username || user.user_metadata?.username || "";
  $("profileBio").value = data?.bio || "";
  $("profileLocation").value = data?.location || "";
}

async function signOut() {
  await client.auth.signOut();
  $("userMenu").style.display="none";
  $("loginBtn").style.display="inline-block";
  $("signupBtn").style.display="inline-block";
  msgGlobal("Logged out.", true);
}

async function refreshUser() {
  const { data: { user } } = await client.auth.getUser();
  if (user) {
    $("loginBtn").style.display="none";
    $("signupBtn").style.display="none";
    $("userMenu").style.display="inline-flex";
    $("userEmail").textContent = user.email;
  } else {
    $("loginBtn").style.display="inline-block";
    $("signupBtn").style.display="inline-block";
    $("userMenu").style.display="none";
  }
}

async function googleLogin() {
  const { error } = await client.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo: window.location.origin + window.location.pathname }
  });
  if (error) msg(error.message);
}

function msgGlobal(text, ok=false){
  const el=$("globalMessage");
  el.textContent=text;
  el.className=ok ? "toast show ok" : "toast show";
  setTimeout(()=>el.classList.remove("show"),3500);
}

client.auth.onAuthStateChange(async (event, session) => {
  await refreshUser();
  if (event === "PASSWORD_RECOVERY") $("resetModal").classList.add("show");
});

$("switchAuth").addEventListener("click", () => openAuth(authMode === "login" ? "signup" : "login"));
