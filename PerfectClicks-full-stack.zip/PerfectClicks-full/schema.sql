-- PerfectClicks: profiles + posts + public photo storage
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  username text unique,
  bio text,
  location text,
  avatar_url text,
  updated_at timestamptz default now()
);
alter table public.profiles enable row level security;
revoke all on table public.profiles from anon;
grant select on table public.profiles to anon, authenticated;
grant insert, update on table public.profiles to authenticated;

drop policy if exists "Profiles are publicly readable" on public.profiles;
create policy "Profiles are publicly readable" on public.profiles for select using (true);
drop policy if exists "Users can insert their own profile" on public.profiles;
create policy "Users can insert their own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  description text not null check (char_length(description) between 1 and 5000),
  category text not null default 'Other',
  post_type text not null default 'photo' check (post_type in ('photo','information')),
  image_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_user_id_idx on public.posts(user_id);
create index if not exists posts_category_idx on public.posts(category);
alter table public.posts enable row level security;
revoke all on table public.posts from anon;
grant select on table public.posts to anon, authenticated;
grant insert, update, delete on table public.posts to authenticated;
drop policy if exists "Anyone can read published posts" on public.posts;
create policy "Anyone can read published posts" on public.posts for select using (true);
drop policy if exists "Users can create their own posts" on public.posts;
create policy "Users can create their own posts" on public.posts for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update their own posts" on public.posts;
create policy "Users can update their own posts" on public.posts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete their own posts" on public.posts;
create policy "Users can delete their own posts" on public.posts for delete to authenticated using (auth.uid() = user_id);

-- Public bucket: post images are intentionally public because post pages are shareable.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('post-images','post-images',true,8388608,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true,file_size_limit=8388608,allowed_mime_types=array['image/jpeg','image/png','image/webp'];

drop policy if exists "Authenticated users can upload their own post images" on storage.objects;
create policy "Authenticated users can upload their own post images" on storage.objects
for insert to authenticated with check (bucket_id='post-images' and (storage.foldername(name))[1]=(select auth.uid()::text));
drop policy if exists "Users can update their own post images" on storage.objects;
create policy "Users can update their own post images" on storage.objects
for update to authenticated using (bucket_id='post-images' and owner_id=(select auth.uid()::text)) with check (bucket_id='post-images' and owner_id=(select auth.uid()::text));
drop policy if exists "Users can delete their own post images" on storage.objects;
create policy "Users can delete their own post images" on storage.objects
for delete to authenticated using (bucket_id='post-images' and owner_id=(select auth.uid()::text));

-- Public bucket reads are available because the bucket is public.
