# PerfectClicks — Auth + Photo Upload + Database + Permanent Share Links

This package extends the PerfectClicks auth prototype into a real Supabase-backed photo/information sharing site.

## Included
- Email/password signup and login
- Forgot password + password recovery
- Google OAuth button
- Profile setup
- Photo upload to Supabase Storage
- JPG/PNG/WebP validation and 8 MB limit
- `posts` PostgreSQL table with RLS
- Public post feed + category filters
- Permanent post URLs such as `post.html?id=<UUID>`
- Copy/share link button
- Owner-only create/update/delete database permissions
- User-owned Storage folders (`<user-id>/...`)

## Setup
1. Create a Supabase project.
2. In `supabase-config.js`, replace the URL and publishable key. Use only the browser-safe publishable/anon key — never a secret/service_role key.
3. In Supabase SQL Editor, run **all of `schema.sql`**.
4. In Authentication > URL Configuration, add your site URL and the redirect URL used by this package.
5. If using Google login, enable Google under Authentication > Providers and configure its OAuth credentials.
6. Upload this folder to your hosting provider.

## Share links
The app generates links like:
`https://your-domain.com/post.html?id=POST_UUID`

These links are stable because the post UUID is stored in PostgreSQL. The image itself is stored in the public `post-images` bucket so the image can be served from the shared post page.

## Important production note
The `post-images` bucket is public by design for public photo posts. Anyone with an image URL can view that image. Upload/delete operations remain protected by Storage RLS policies.

If you later need private posts, switch to a private bucket and generate time-limited signed URLs instead.
