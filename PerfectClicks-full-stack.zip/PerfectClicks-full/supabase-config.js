window.SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.SUPABASE_PUBLISHABLE_KEY = "YOUR_SUPABASE_PUBLISHABLE_KEY";
// Never put a Supabase secret/service_role key in this browser file.
