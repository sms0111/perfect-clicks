const POST_BUCKET = "post-images";
window.currentCategory = "all";

function uploadMsg(t, ok=false){const e=document.getElementById('uploadMessage');e.textContent=t;e.className=ok?'message success':'message error';e.style.display='block'}
function openUpload(){ client.auth.getUser().then(({data})=>{if(!data.user){openAuth('login');return} document.getElementById('uploadMessage').style.display='none';document.getElementById('uploadModal').classList.add('show')}) }
function closeUpload(){document.getElementById('uploadModal').classList.remove('show')}

async function createPost(){
  const {data:{user}}=await client.auth.getUser(); if(!user){openAuth('login');return}
  const type=document.getElementById('postType').value, title=document.getElementById('postTitle').value.trim(), description=document.getElementById('postDescription').value.trim(), category=document.getElementById('postCategory').value, file=document.getElementById('photoFile').files[0];
  if(!title) return uploadMsg('Please enter a title.');
  if(!description) return uploadMsg('Please add a description or information.');
  if(type==='photo' && !file) return uploadMsg('Please choose a photo.');
  if(file && file.size>8*1024*1024) return uploadMsg('Photo must be 8 MB or smaller.');
  if(file && !['image/jpeg','image/png','image/webp'].includes(file.type)) return uploadMsg('Only JPG, PNG and WebP images are allowed.');
  uploadMsg('Publishing...', true);
  let image_path=null;
  if(file){
    const ext=(file.name.split('.').pop()||'jpg').toLowerCase();
    image_path=`${user.id}/${crypto.randomUUID()}.${ext}`;
    const {error}=await client.storage.from(POST_BUCKET).upload(image_path,file,{contentType:file.type,cacheControl:'31536000',upsert:false});
    if(error) return uploadMsg(error.message);
  }
  const {data,error}=await client.from('posts').insert({user_id:user.id,title,description,category,post_type:type,image_path}).select('id').single();
  if(error){if(image_path) await client.storage.from(POST_BUCKET).remove([image_path]);return uploadMsg(error.message)}
  const share=`${window.location.origin}/post.html?id=${encodeURIComponent(data.id)}`;
  closeUpload();
  resetUploadForm();
  await loadPosts();
  showToast('Published! Share link copied.');
  try{await navigator.clipboard.writeText(share)}catch(e){}
  setTimeout(()=>{if(confirm('Post published. Open your permanent share link?')) location.href=share},100);
}
function resetUploadForm(){['postTitle','postDescription'].forEach(id=>document.getElementById(id).value='');document.getElementById('photoFile').value='';document.getElementById('photoPreview').style.display='none';}

async function loadPosts(){
  const grid=document.getElementById('postGrid'), empty=document.getElementById('emptyState'); grid.innerHTML='';
  let q=client.from('posts').select('id,title,description,category,post_type,image_path,created_at,user_id,profiles(full_name,username)').order('created_at',{ascending:false}).limit(60);
  if(window.currentCategory && window.currentCategory!=='all') q=q.eq('category',window.currentCategory);
  const {data,error}=await q;
  if(error){grid.innerHTML=`<div class="empty">${escapeHtml(error.message)}</div>`;return}
  empty.classList.toggle('hidden',!data.length);
  for(const p of data){
    const image=p.image_path ? client.storage.from(POST_BUCKET).getPublicUrl(p.image_path).data.publicUrl : '';
    const card=document.createElement('article'); card.className='card';
    card.innerHTML=`${image?`<img class="thumb" src="${escapeAttr(image)}" alt="">`:''}<div class="card-body"><div class="tag">${escapeHtml(p.category)}</div><h3>${escapeHtml(p.title)}</h3><p class="muted">${escapeHtml(p.description.slice(0,150))}${p.description.length>150?'…':''}</p><div class="meta"><span>${escapeHtml(p.profiles?.username?('@'+p.profiles.username):(p.profiles?.full_name||'Member'))}</span><span>${new Date(p.created_at).toLocaleDateString()}</span></div><div class="card-actions"><a class="btn primary small" href="post.html?id=${encodeURIComponent(p.id)}">View Post</a><button class="btn secondary small" onclick="copyShare('${p.id}')">Share</button></div></div>`;
    grid.appendChild(card);
  }
}
async function copyShare(id){const url=`${window.location.origin}/post.html?id=${encodeURIComponent(id)}`;try{await navigator.clipboard.writeText(url);showToast('Share link copied.')}catch(e){prompt('Copy this link:',url)}}
function showToast(t){const e=document.getElementById('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2800)}
function escapeHtml(s=''){return s.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function escapeAttr(s=''){return escapeHtml(s)}
